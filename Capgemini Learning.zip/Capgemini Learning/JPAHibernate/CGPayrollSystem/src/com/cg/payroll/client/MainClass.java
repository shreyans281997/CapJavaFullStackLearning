package com.cg.payroll.client;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		//int associateId1=services.acceptAssociateDetails("Shreyansh", "Jain", "reyj.028@gmail.com" ,"FSBU", "Analyst", "00A21", 1000, 6000, 21600, 15000, 4563450, "AXIS Bank", "9845675");
		//System.out.println(associateId1);
		//int associateId2=services.acceptAssociateDetails("Reyansh", "Jain", "shreyj@gmail.com" ,"FSBBU", "Intern", "CD0021", 2000, 12000, 1000, 10090, 9734533, "HDFC Bank", "0456975");
		//int associateId3=services.acceptAssociateDetails("ishu", "sharma", "ish@gmail.com" ,"FSBU", "Analyst", "AB1121", 2000, 15000, 1000, 10090, 1024533, "ICICI Bank", "7645675");
		//System.out.println("Associate Id 1:- "+associateId1);
		//System.out.println("Associate Id 2:- "+associateId3);
		System.out.println(services.getAllAssociatesDetails());
		//System.out.println(services.calculateNetSalary(1));
	   //System.out.println(  services.calculateNetSalary(103));
		//System.out.println(services.getAssociateDetails(5));
	}
}

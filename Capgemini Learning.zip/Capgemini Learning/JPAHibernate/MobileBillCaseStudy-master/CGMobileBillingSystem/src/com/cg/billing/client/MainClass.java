package com.cg.billing.client;
import java.util.Scanner;

import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		char continueChoice;
		BillingServices services=new BillingServicesImpl();
		Scanner scan=new Scanner(System.in);
		do {
			System.out.println("Enter 1 for customer registration "
					+ "\nEnter 2 for plans "
					+ "\nEnter 3 for open postpaid account"
					+ "\nEnter 4 to generate monthly bill"
					+ "\nEnter 5 to see customer details"
					+ "\nEnter 6 to get postpaid account details"
					+ "\nEnter 7 to get details of all postpaid accounts of a customer"
					+ "\nEnter 8 to get monthly bill details"
					+ "\nEnter 9 to change plan"
					+ "\nEnter 10 to get customer postpaid account plan details"
					+ "\nEnter 11 to close account"
					+ "\nEnter 12 to delete customer"
			        + "\nEnter 13 to see all customer details");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:{
				System.out.println("Enter your First Name:");
				String firstName=scan.next().toUpperCase();
				System.out.println("Enter your Last Name:");
				String lastName=scan.next().toUpperCase();
				System.out.println("Enter your email Name:");
				String emailID=scan.next().toUpperCase();
				System.out.println("Enter your Date of Birth:");
				String dateOfBirth=scan.next();
				System.out.println("Enter your Billing Address City:");
				String billingAddressCity=scan.next().toUpperCase();
				System.out.println("Enter your billing Address State:");
				String billingAddressState=scan.next().toUpperCase();
				System.out.println("Enter your billing Address pinCode:");
				int billingAddressPinCode=scan.nextInt();
				System.out.println("Enter your Home Address city:");
				String homeAddressCity=scan.next().toUpperCase();
				System.out.println("Enter your home address State:");
				String homeAddressState=scan.next().toUpperCase();
				System.out.println("Enter your home pin Code:");
				int homeAddressPinCode=scan.nextInt();
				int customerId=services.acceptCustomerDetails(firstName, lastName, emailID, dateOfBirth, billingAddressCity, billingAddressState, billingAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
				System.out.println("Your customer Id: "+customerId);
				break;
			}
			case 2:
				System.out.println(services.getPlanAllDetails());
				break;
			case 3:{
				System.out.println("Enter customer ID: ");
				int customerID=scan.nextInt();
				System.out.println("Enter plan ID ");
				int planID=scan.nextInt();
				long mobileNumber;
				try {
					mobileNumber = services.openPostpaidMobileAccount(customerID, planID);
					System.out.println("Your Mobile Number is: "+mobileNumber);
				} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException e) {
					System.out.println(e.getMessage());
				}
			}
			break;
			case 4:{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				System.out.println("Enter your mobile number: ");
				long mobileNo=scan.nextLong();
				System.out.println("Enter the month of billing: ");
				String billMonth=scan.next().toUpperCase();
				System.out.println("Enter Number of local sms: ");
				int noOfLocalSMS=scan.nextInt();
				System.out.println("Enter number of std sms: ");
				int noOfStdSMS=scan.nextInt();
				System.out.println("Enter number of local calls: ");
				int noOfLocalCalls=scan.nextInt();
				System.out.println("Enter number of std calls: ");
				int noOfStdCalls=scan.nextInt();
				System.out.println("Enter your internet usage in mb:");
				int internetDataUsageUnits=scan.nextInt();
				try {
					System.out.println("Your bill for "+billMonth+" is: "+services.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits));
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
						| PlanDetailsNotFoundException e) {
					System.out.println(e.getMessage());
				}	
			}
			break;
			case 5:
			{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				try {
					System.out.println(services.getCustomerDetails(customerID));
				} catch (CustomerDetailsNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			}
			case 6:
			{
				System.out.println("Enter customer ID:");
				int customerId=scan.nextInt();
				System.out.println("Enter mobile number/postpaidAccountId: ");
				int mobileNo=scan.nextInt();
				try {
					System.out.println(services.getPostPaidAccountDetails(customerId, mobileNo));
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
			}
			break;
			case 7:{
				System.out.println("Enter customer ID:");
				int customerId=scan.nextInt();
				try {
					System.out.println(services.getCustomerAllPostpaidAccountsDetails(customerId));
				} catch (CustomerDetailsNotFoundException e) {
					System.out.println("Customer not found");
				}
			}
			break;
			case 8:
			{
				System.out.println("Enter customer ID:");
				int customerId=scan.nextInt();
				System.out.println("Enter mobile number/postpaidAccountId: ");
				int mobileNo=scan.nextInt();
				System.out.println("Enter bill month:");
				String billMonth=scan.next().toUpperCase();
				try {
					System.out.println(services.getMobileBillDetails(customerId, mobileNo, billMonth));
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException
						| InvalidBillMonthException | BillDetailsNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			}
			case 9:{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				System.out.println("Enter mobile number/postpaidAccountId: ");
				int mobileNo=scan.nextInt();
				System.out.println("Enter new plan ID");
				int planID=scan.nextInt();
				try {
					services.changePlan(customerID, mobileNo, planID);
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
				try {
					System.out.println("Your new plan :"+services.getPostPaidAccountDetails(customerID, mobileNo).getPlan());
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
			}
			break;
			case 10:{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				System.out.println("Enter mobile number/postpaidAccountId: ");
				int mobileNo=scan.nextInt();
				try {
					System.out.println(services.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo));
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException
						| PlanDetailsNotFoundException e) {
					System.out.println(e.getMessage());
				}
			}
			break;
			case 11:{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				System.out.println("Enter mobile number/postpaidAccountId: ");
				int mobileNo=scan.nextInt();
				try {
					services.closeCustomerPostPaidAccount(customerID, mobileNo);
					System.out.println("Your account has been closed");
				} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
			}
			break;
			case 12:{
				System.out.println("Enter customer ID:");
				int customerID=scan.nextInt();
				try {
					services.removeCustomerDetails(customerID);
					System.out.println("Customer has been deleted");
				} catch (CustomerDetailsNotFoundException e) {
					System.out.println("Invalid Customer ID");
				}
			}
			case 13:{
				System.out.println(services.getAllCustomerDetails());
			}
			break;
			default:
				System.out.println("Wrong option.Please enter correct option");
			}
			System.out.println("Do you want to continue (y or n): ");
			continueChoice=scan.next().charAt(0);
		}
		while(continueChoice=='y'||continueChoice=='Y');
	}
}
package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.DaoService;
import com.capgemini.xyz.dao.IDaoService;

public class LoanService implements ILoanService {
	IDaoService daoService=new DaoService();
@Override
	public Loan applyLoan(Loan loan) {
		return daoService.applyLoan(loan);
	}
@Override
	public Customer validateCustomer(Customer customer) {
		
		return null;
	}
@Override
	public long insertCust(Customer cust) {
		return daoService.insertCust(cust);
		
	}

}

package com.capgemini.xyz.ui;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.util.CustomerDB;

public class ExecuteMain {
	public static void main(String args[]) {
	ILoanService services=new LoanService();
	Customer cust=new Customer("Shreyansh", "mbd", 656533535, "sfdsfd");
    System.out.println(services.insertCust(cust));
}
	}

package com.capgemini.xyz.util;
import java.util.HashMap;
import com.capgemini.xyz.bean.Customer;
public class CustomerDB {
public static HashMap <Long ,Customer> customerDB=new HashMap<>();
public static long getCustomerId() {
	return (long)(Math.random()*10000);
}
}
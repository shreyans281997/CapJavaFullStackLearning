package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.util.CustomerDB;
import com.capgemini.xyz.util.LoanDB;

public class DaoService implements IDaoService {

	@Override
	public long applyLoan(Loan loan) {
		loan.setLoanID(LoanDB.getLoanId());
		LoanDB.loanDB.put(LoanDB.getLoanId(), loan);
		return 0;
	}

	@Override
	public long insertCust(Customer cust) {
		cust.setCustId(CustomerDB.getCustomerId());
		CustomerDB.customerDB.put(cust.getCustId(), cust);
		return cust.getCustId();
	}

}

package com.capgemini.xyz.util;
import java.util.HashMap;
import com.capgemini.xyz.bean.Loan;
public class LoanDB {
	public static HashMap <Long ,Loan> loanDB=new HashMap<>();
	public static long getLoanId() {
		return (long)(Math.random()*10000);
	}

}

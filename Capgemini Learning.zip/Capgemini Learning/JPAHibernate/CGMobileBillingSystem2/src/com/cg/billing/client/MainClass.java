package com.cg.billing.client;

import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		BillingServices services=new BillingServicesImpl();
		services.acceptCustomerDetails("Shreyansh", "Jain", "rsar@", "28sep", "mbd", "Sf", 253, "Gggg", "hgjg",343);
	}
}
package com.cg.billing.daoservices;
import com.cg.billing.beans.Customer;

public interface BillingServicesDao {


Customer save(Customer customer);
}

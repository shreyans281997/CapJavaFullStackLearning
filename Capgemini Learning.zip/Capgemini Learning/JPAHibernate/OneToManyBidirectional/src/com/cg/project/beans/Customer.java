package com.cg.project.beans;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerNo;
	private String firstName,lastName,email;
	@OneToMany(mappedBy="customer")
	@MapKey
    private Map<Integer,Car> cars;
    public Customer() {}
	

	
}

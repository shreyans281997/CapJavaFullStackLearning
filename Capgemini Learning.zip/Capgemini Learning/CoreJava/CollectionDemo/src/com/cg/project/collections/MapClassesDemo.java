package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

import com.cg.project.beans.Associate;

public class MapClassesDemo {
	public static void mapClassesDemo(){
		Hashtable<Integer, Associate> associates=new Hashtable<>();
		associates.put(101,new Associate(101,"Shreyansh","Jain",15000));
		associates.put(201,new Associate(201,"Anil","Kumar",11000));
		associates.put(301,new Associate(301,"Reyansh","Jain",25000));
		associates.put(401,new Associate(401,"MS","Dhoni",1000000));
	    //System.out.println(associates.get(101));
		Associate associate= associates.get(101);
		System.out.println(associate);
	    
	   // Set<Integer> keys=associates.keySet();
	   // for(Integer key:keys) {
	    	//System.out.println(associates.get(key));
	    }
	    	
	   // ArrayList<Associate> list=new ArrayList<Associate>(associates.values());
	  //for(Associate asc:list) {
	  //  System.out.println(asc);
	 //   }
	    
}//}



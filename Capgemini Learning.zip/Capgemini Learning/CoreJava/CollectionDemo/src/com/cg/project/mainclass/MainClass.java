package com.cg.project.mainclass;

import com.cg.project.collections.LinkedListClassDemo;
import com.cg.project.collections.ListClassesDemo;
import com.cg.project.collections.MapClassesDemo;
import com.cg.project.collections.SetClassesDemo;

public class MainClass {
	public static void main(String args[])
	{
		/*ListClassesDemo demo=new ListClassesDemo();
		demo.arrayListClassDemo();*/
		//LinkedListClassDemo linkDemo=new LinkedListClassDemo();
		//linkDemo.linkedListClassDemo();
		
		 //SetClassesDemo setDemo=new SetClassesDemo();
		//setDemo.hashSetClassDemo();
		
		MapClassesDemo mapDemo=new MapClassesDemo();
		mapDemo.mapClassesDemo();
		
	}

}

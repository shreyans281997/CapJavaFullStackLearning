package com.cg.project.collections;
import java.util.HashSet;

import com.cg.project.beans.Associate;
public class SetClassesDemo {
	public static void hashSetClassDemo() {
		HashSet<Associate> associate=new HashSet<>();
		associate.add(new Associate(001,"Shreyansh","Jain",15000));
		associate.add(new Associate(002,"Anil","Kumar",11000));
		associate.add(new Associate(003,"Reyansh","Jain",25000));
		associate.add(new Associate(004,"MS","Dhoni",1000000));
		
		System.out.println(associate.toString());
		System.out.println(associate.contains(new Associate(003,"Reyansh","Jain",25000)));
		
	}
	

}

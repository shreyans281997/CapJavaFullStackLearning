package com.cg.project.collections;
import java.util.Collections;
import java.util.LinkedList;

import com.cg.project.beans.Associate;
import com.cg.project.beans.AssociateComparator;

public class LinkedListClassDemo {
	public static void linkedListClassDemo()
	{
	LinkedList<String> strList=new LinkedList<>();
	strList.add("Shreyansh");
	strList.add("Sidhant");
	strList.add("Ishi");
	System.out.println(strList);
	
	//search
	String nameToBeSearch="Shreyansh";
	System.out.println(strList.contains(nameToBeSearch));
	
	System.out.println(strList.indexOf(nameToBeSearch));
	System.out.println(strList.indexOf("Sidhant"));
	
	int index=strList.indexOf(nameToBeSearch);
	System.out.println(strList.get(index));
	
	//Associate ArrayList
	LinkedList<Associate> associate=new LinkedList<>();
	associate.add(new Associate(001,"Shreyansh","Jain",15000));
	associate.add(new Associate(002,"Anil","Kumar",11000));
	associate.add(new Associate(003,"Reyansh","Jain",25000));
	associate.add(new Associate(004,"MS","Dhoni",1000000));
	
	System.out.println(associate.toString());
	System.out.println(associate.contains(new Associate(003,"Reyansh","Jain",25000)));
	
	int searchIndex=associate.indexOf(new Associate(003,"Reyansh","Jain",25000));
	System.out.println(searchIndex);
	System.out.println(associate.get(searchIndex));
	
	//sorting
	Collections.sort(strList);
	System.out.println(strList);
	Collections.sort(associate);
	System.out.println(associate);
	
	System.out.println("----------------");
	Collections.sort(associate,new AssociateComparator());
	for(Associate associates:associate)
		System.out.println(associates);
	}
}

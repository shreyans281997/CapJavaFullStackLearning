package com.cg.equalsmethoddemo.main;
import com.cg.equalsmethoddemo.beans.Employee;

public class MainClass {
	public static void main(String args[])
	{
		Employee e1=new Employee("Shreyansh","Jain",01);
		Employee e2=new Employee("Shreyansh","Jain",01);
		Object e3=e2;
		Object ob1=new Employee("Shreyansh", "Jain", 01);
		//e2=(Employee) ob1;
		Object ob2=new Object();
		ob2=e1;
		System.out.println(e1.equals(e2));
		System.out.println(e3.equals(e2));
	}

}

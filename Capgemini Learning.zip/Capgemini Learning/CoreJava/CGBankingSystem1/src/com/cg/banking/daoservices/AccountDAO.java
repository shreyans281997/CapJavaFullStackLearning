package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import java.util.List;
public interface AccountDAO {
	Account save(Account account);
	boolean update(Account account);
	Account findOne(long accountNo);
	List<Account> findAll();

}

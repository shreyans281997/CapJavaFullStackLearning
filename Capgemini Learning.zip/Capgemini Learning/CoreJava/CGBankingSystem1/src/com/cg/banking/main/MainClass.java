package com.cg.banking.main;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDB;

public class MainClass {
	public static void main(String args[])
	{
		
		char continueChoice='y';
		Scanner scan=new Scanner(System.in);
	BankingServicesImpl bankingService=new BankingServicesImpl();
	do{
	System.out.println("Enter your choice : ");
	System.out.println("Press 1 to open account \n Press 2 to deposit money "
			+ "\n Press 3 to withdraw money \nPress 4 to transfer funds"
			+ " \nPress 5 to get account details");
	int choice=scan.nextInt();
	switch (choice)
	{
	case 1:
	{
	System.out.println("Enter type of account (Savings or current) : ");
	String accountType=scan.next();
	System.out.println("Enter initial balance: ");
	float initialBalance=scan.nextFloat();
   System.out.println(bankingService.openAccount(accountType,initialBalance));
	break;
	}
	case 2:
	{
		System.out.println("Enter your account number:");
		long accNumber=scan.nextLong();
		System.out.println("Enter amount to deposit: ");
		float amt=scan.nextFloat();
		try {
		System.out.println(bankingService.depositAmount(accNumber, amt)); }
		catch(AccountNotFoundException e) {
			System.out.println("Account Not found. Please enter valid account number");
		}
		break;
	}
	case 3:
	{

		System.out.println("Enter your account number:");
		long accNumber=scan.nextLong();
		System.out.println("Enter amount to withdraw: ");
		float amt=scan.nextFloat();
		System.out.println("Enter pin: ");
		int pinNumber=scan.nextInt();
		try {
		System.out.println(bankingService.withdrawAmount(accNumber, amt,pinNumber)); }
		catch(AccountNotFoundException e) {
			System.out.println("Account Not found. Please enter valid account number");

		}
		catch(InvalidPinNumberException e) {
			System.out.println("Please enter valid PIN NUMBER");
			
				}
		catch(InsufficientAmountException e)
		{
			System.out.println("Insufficient amount in your account ");
		}
	}
		break;
	case 4:
	{
		System.out.println("Enter your account number: ");
		long fromAcc=scan.nextLong();
		System.out.println("Enter account number to deposit: ");
		long toAcc=scan.nextLong();
		System.out.println("Enter amount: ");
		float transfer=scan.nextFloat();
		System.out.println("Enter pin : ");
		int pinNumber=scan.nextInt();
		try {
		System.out.println(bankingService.fundTransfer(toAcc, fromAcc, transfer, pinNumber)); }
		catch(AccountNotFoundException e) {
			System.out.println("Account Not found. Please enter valid account number");
		}
		catch(InvalidPinNumberException e) {
			System.out.println("Please enter valid PIN NUMBER");
				}
		catch(InsufficientAmountException e)
		{
			System.out.println("Insufficient amount in your account ");
		}
		break;
	}
	case 5:
	{
		System.out.println("Enter your account number:");
		long accNumber=scan.nextLong();
		try {
		System.out.println(bankingService.getAccountDetails(accNumber));
		}
		catch(AccountNotFoundException e) {
			System.out.println("Account Not found. Please enter valid account number");
		}
		break;
	}
	default:
		System.out.println("Wrong choice");
	}
	System.out.println("Do you want to continue (y or n): ");
	 continueChoice=scan.next().charAt(0);
   }
	while(continueChoice=='y'||continueChoice=='Y');
	}
	
	
}   

		
		
package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDB;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDB.getAccNumber());
		account.setPinNumber(BankingDB.getPinNumber());
		account.setAccountStatus(BankingDB.getAccStatus());
		BankingDB.accountDB.put(account.getAccountNo(), account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		BankingDB.accountDB.put(account.getAccountNo(), account);
		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		return BankingDB.accountDB.get(accountNo);
	}

	@Override
	public List<Account> findAll() {
		
		return new ArrayList<>(BankingDB.accountDB.values());
	}

}

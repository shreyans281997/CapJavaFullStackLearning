package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.excpetions.InvalidCategoryException;
import com.capgemini.salesmanagement.excpetions.InvalidPriceException;
import com.capgemini.salesmanagement.excpetions.InvalidQuantityException;
import com.capgemini.salesmanagement.excpetions.ProductCodeException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
		ISaleService saleService=new SaleService();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter product code: ");
		int code=scan.nextInt();
		System.out.println("Enter quanity:");
		int quant=scan.nextInt();
		LocalDate currDate=LocalDate.now();
		Sale sale=new Sale(code, quant);
		sale.setSaleDate(currDate);
		try {
	   saleService.insertSalesDetails(sale);
	   System.out.println("ID : "+sale.getSaleId());
	   System.out.println("Product Category : "+sale.getCategory());
	   System.out.println("Product Description : "+sale.getProductName());
	   System.out.println("Product Price : "+sale.getPrice());
	   System.out.println("Quantity: "+sale.getQuantity());
	   System.out.println("Purchase Date:"+sale.getSaleDate());
	   System.out.println("Line Total(Rs): "+sale.getLineTotal());
	   
}
		catch(InvalidCategoryException e) {
			System.out.println("Category should be electronics or toys"); }
		catch(InvalidPriceException e) {
			System.out.println("Price should be greater than 200"); }
		catch(InvalidQuantityException e) {
			System.out.println("Quantity should be greater than 0 and less than 5"); }
		catch(ProductCodeException e) {
			System.out.println("Product code not valid");
		}
	}

}

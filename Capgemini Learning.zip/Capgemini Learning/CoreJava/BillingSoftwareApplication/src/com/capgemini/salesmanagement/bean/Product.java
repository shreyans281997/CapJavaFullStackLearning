package com.capgemini.salesmanagement.bean;

public class Product {
	String cateogry;
	String name;
	int code;
	

}

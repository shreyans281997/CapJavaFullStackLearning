package com.capgemini.salesmanagement.testservices;
import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.excpetions.InvalidCategoryException;
import com.capgemini.salesmanagement.excpetions.InvalidQuantityException;
import com.capgemini.salesmanagement.excpetions.ProductCodeException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;
public class SalesManagementTest {

    private static ISaleService services;
    @BeforeClass
    public static void setUpTestEnv() {
        services=new SaleService();
    }
    @Before
    public void setUpTestData() {
        Sale sale1=new Sale(21,"Phone", "Electronics", LocalDate.now(), 2, 7000);
        Sale sale2=new Sale(11,"Video game", "Electronics", LocalDate.now(), 3, 7500);
    }
    
    @Test
    public void testForValidProductId() throws ProductCodeException {
        boolean expected=true;
        boolean actual=services.validateProductCode(1001);
        Assert.assertEquals(expected, actual);
    }
 
 
   
    @After
    public void tearDownTestData() {
        CollectionUtil.sales.clear();
    }
    @AfterClass
    public static void tearDownTestEnv() {
        services=null;
    }

}

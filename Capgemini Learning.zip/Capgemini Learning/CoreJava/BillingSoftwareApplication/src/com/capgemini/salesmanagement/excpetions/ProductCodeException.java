package com.capgemini.salesmanagement.excpetions;

public class ProductCodeException extends RuntimeException {

	public ProductCodeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductCodeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProductCodeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductCodeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductCodeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}

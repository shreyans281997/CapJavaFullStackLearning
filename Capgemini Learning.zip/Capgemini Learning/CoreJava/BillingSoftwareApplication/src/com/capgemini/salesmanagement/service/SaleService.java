package com.capgemini.salesmanagement.service;
import java.util.HashMap;

import javax.swing.text.html.InlineView;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.excpetions.InvalidCategoryException;
import com.capgemini.salesmanagement.excpetions.InvalidPriceException;
import com.capgemini.salesmanagement.excpetions.InvalidQuantityException;
import com.capgemini.salesmanagement.excpetions.ProductCodeException;
public class SaleService implements ISaleService {
	ISaleDAO saleDao=new SaleDAO();
	@Override
	public Sale insertSalesDetails(Sale sale) {
		if(!(validateProductCode(sale.getProdCode()))) {
			throw new ProductCodeException("Product code not valid");
		}
		else if(!(validateQuantity(sale.getQuantity())))
			throw new InvalidQuantityException("Invalid quantity");
		else
			sale=saleDao.insertSalesDetails(sale);
		if(!(validateProductCat(sale.getCategory())))
			throw new InvalidCategoryException();
		else if(!(validateProductPrice(sale.getPrice())))
			throw new InvalidPriceException();
		return sale;
	}

	@Override
	public boolean validateProductCode(int productId) {
		if(productId==1001||productId==1002||productId==1003||productId==1004||productId==1005||productId==1006)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateQuantity(int qty) throws InvalidQuantityException {
		if(qty>0&&qty<5)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		if(prodCat.equalsIgnoreCase("electronics")||prodCat.equalsIgnoreCase("toys"))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateProductName(String prodName) {
		return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		if(price>200)
			return true;
		else
			return false;
	}


}

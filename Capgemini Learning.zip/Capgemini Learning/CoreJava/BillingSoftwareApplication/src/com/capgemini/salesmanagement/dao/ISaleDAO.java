package com.capgemini.salesmanagement.dao;
import java.util.HashMap;
import com.capgemini.salesmanagement.bean.Sale;
public interface ISaleDAO {
public Sale insertSalesDetails(Sale sale);
public Sale findOne(Sale sale);
}

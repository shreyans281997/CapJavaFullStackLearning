package com.cg.project.client;
import com.cg.project.threadwork.RunnableResource;
public class MainClass {
	public static void main(String[] args) {
		RunnableResource resource=new RunnableResource();
		Thread th1=new Thread(resource, "tickThread");
		Thread th2=new Thread(resource, "tockThread");
		th1.start();
		th2.start();
	}
}

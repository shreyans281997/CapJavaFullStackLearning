package com.cg.project.threadwork;
public class RunnableResource implements Runnable {
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		if(t.getName().equals("tickThread"))
			for(int i=1;i<=10;i++)
				System.out.println("Tick :"+i);
		if(t.getName().equals("tockThread"))
			for(int i=1;i<=10;i++)
				System.out.println("Tock :"+i);
		System.out.println("End of thread task");
	}
}
package com.cg.project.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.locks.Condition;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.project.beans.Employee;

public class MainClass {
	public static void main(String args[]) {
		
ArrayList<Employee> empList=new ArrayList<>();
empList.add(new Employee(111,12000, "Shreyansh"));
empList.add(new Employee(112, 20000, "MSDhoni"));
empList.add(new Employee(113, 27567, "Rey"));

//Comparator<Employee> comparator=(emp1,emp2)->emp1.getBasicSalary()-emp2.getBasicSalary();
//Collections.sort(empList,comparator);

//Collections.sort(empList, (e1,e2)->e1.getBasicSalary()-e2.getBasicSalary());

printEmployeeDetailsPredicate(empList,(employee)->employee.getEmpName().startsWith("S"));
System.out.println("---------------------------------------------------------");
printEmployeeDetailsPredicate(empList, (employee)-> {
	if(employee.getBasicSalary()>10000)
		return true;
	else return false;
});
	}

	private static void printEmployeeDetailsPredicate(ArrayList<Employee> empList,Predicate<Employee> condition) {
		for(Employee employee:empList)
			if(condition.test(employee)) {
				System.out.println(employee);
			}
		Stream<Employee> stream1=empList.stream();
		Stream<Employee> stream2=stream1.distinct();
		Stream<Employee> stream3=stream2.filter((employee)->employee.getEmpName().startsWith("N"));
		System.out.println(stream3.count());
		stream3.forEach(employee->System.out.println(employee));
		System.out.println(empList.stream().map(employee->employee.getBasicSalary()));
		
		
		
	}
}

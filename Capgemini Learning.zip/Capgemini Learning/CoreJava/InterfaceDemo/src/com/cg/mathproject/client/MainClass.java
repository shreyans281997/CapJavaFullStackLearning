package com.cg.mathproject.client;
public class MainClass {
	
}

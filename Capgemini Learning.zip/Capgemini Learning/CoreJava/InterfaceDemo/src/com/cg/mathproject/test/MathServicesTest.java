package com.cg.mathproject.test;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServiesImpl;
public class MathServicesTest {
	private static MathServiesImpl services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new MathServiesImpl();
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForFirstNumberInvalid() throws NegativeNumberException{
		services.add(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForSecondNumberInvalid() throws NegativeNumberException{
		services.add(100, -200);
	}
	@Test
	public void testAddForBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(300, services.add(100, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubtractForFirstNumberInvalid() throws NegativeNumberException{
		services.sub(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubtractForSecondNumberInvalid() throws NegativeNumberException{
		services.sub(-100, 200);
	}
	@Test
	public void testSubtractBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(300, services.sub(400, 100));
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivideForFirstNumberInvalid() throws NegativeNumberException{
		 services.div(-400, 100);
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivideForSecondNumberInvalid() throws NegativeNumberException{
		services.div(400, -100);
	}
	@Test
	public void testDivideBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(4, services.div(400, 100));
	}
	@Test(expected=NegativeNumberException.class)
	public void testMultiplyFirstNumberInvalid() throws NegativeNumberException{
		services.multi(-400, 100);
	}
	@Test(expected=NegativeNumberException.class)
	public void testMultiplySecondNumberInvalid() throws NegativeNumberException{
		services.multi(400, -100);
	}
	@Test
	public void testMultiplyBothNumberValid() throws NegativeNumberException{
		Assert.assertEquals(4000, services.multi(400, 10));
	}
	public static void tearDownTestEnv() {
		services=null;
	}
}

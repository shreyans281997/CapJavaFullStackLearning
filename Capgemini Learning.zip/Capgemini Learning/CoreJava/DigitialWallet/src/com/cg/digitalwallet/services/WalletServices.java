package com.cg.digitalwallet.services;
public class WalletServices {

}

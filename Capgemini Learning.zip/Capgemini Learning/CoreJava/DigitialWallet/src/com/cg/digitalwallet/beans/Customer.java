package com.cg.digitalwallet.beans;
public class Customer {

}

package com.domain.filter;

public enum PromotionType {
    MARKED_PRICE,
    BUY_ONE_GET_ONE,
    BUY_THREE_FOR_PRICE_OF_TWO,
}

package com.domain.exception;

public class ItemNotSameTypeException extends Exception {

    public ItemNotSameTypeException(String message) {
        super(message);
    }
}

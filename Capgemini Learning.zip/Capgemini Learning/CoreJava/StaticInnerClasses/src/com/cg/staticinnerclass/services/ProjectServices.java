package com.cg.staticinnerclass.services;

public interface ProjectServices {
	void developeProject();

}

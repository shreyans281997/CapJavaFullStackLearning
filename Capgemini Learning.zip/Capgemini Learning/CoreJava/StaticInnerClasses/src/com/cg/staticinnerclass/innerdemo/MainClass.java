package com.cg.staticinnerclass.innerdemo;
public class MainClass {
		public static void main(String args[]) {
		//simple inner class
		HotelClass.VegKitchen vegKitchen=new HotelClass.VegKitchen();
		HotelClass.NonVegKitchen nonVegKitchen=new HotelClass.NonVegKitchen();
		}
	}


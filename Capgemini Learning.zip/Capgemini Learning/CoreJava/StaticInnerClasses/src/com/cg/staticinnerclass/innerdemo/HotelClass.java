package com.cg.staticinnerclass.innerdemo;
public class HotelClass {
	interface FoodOrderLisnter{
		void cookAFood(String foodName);
	}
	static class VegKitchen implements FoodOrderLisnter{

		@Override
		public void cookAFood(String foodName) {
			System.out.println("Food name is ready: "+foodName);
			}

}
	static class NonVegKitchen implements FoodOrderLisnter{

		@Override
		public void cookAFood(String foodName) {
			System.out.println("Food name is ready: "+foodName);
			
		}
		
	}
}

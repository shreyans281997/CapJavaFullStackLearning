package com.cg.staticinnerclass.client;

import com.cg.staticinnerclass.services.ProjectServices;

public class MainClass {
		public static void main(String args[]) {
	    ProjectServices services=new ProjectServices() {
			
			@Override
			public void developeProject() {
				System.out.println("It project has developed");
				
			}
		};
		}
	}


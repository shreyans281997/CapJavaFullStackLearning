package com.cg.projectinner.innerdemo;

public class MainClass {
	public static void main(String args[]) {
	//simple inner class
	HotelClass hotel=new HotelClass();
	HotelClass.VegKitchen vegKitchen=hotel.new VegKitchen();
	HotelClass.NonVegKitchen nonVegKitchen=hotel.new NonVegKitchen();
	}
}

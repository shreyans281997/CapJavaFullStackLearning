
public class WrapperClass {
	public static void main(String args[])
	{
		int num1=100;
		Integer num2=new Integer(10);
		int res=num1+num2; //unboxing
		Integer newRes=num1+num2; // unboxing---autoboxing 
		System.out.println(res+" "+newRes);
		
		int num3=num2; //unboxing
		int res2=num1+num3; //nothing
	   System.out.println(res2);
	   
		int num5=20;
		Integer num6=20; //autboxing
		System.out.println(num6.equals(num5));
		}

}

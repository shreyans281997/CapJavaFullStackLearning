package com.cg.supermarket.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.supermarket.beans.Customer;
import com.cg.supermarket.beans.Order;
import com.cg.supermarket.daoservices.CustomerDaoServices;
import com.cg.supermarket.daoservices.CustomerDaoServicesImpl;
import com.cg.supermarket.exceptions.AlreadyRegisteredException;
import com.cg.supermarket.exceptions.CustomerNotFoundException;
import com.cg.supermarket.exceptions.InvalidMobileNumberException;
import com.cg.supermarket.exceptions.InvalidOccupationExcpetion;
import com.cg.supermarket.exceptions.ProductNotFoundException;
import com.cg.supermarket.util.OrderDB;
import com.cg.supermarket.util.ProductDB;
import com.cg.supermarket.util.SuperMarketDB;
public class ServicesImpl implements MarketServices{
	CustomerDaoServices daoServices=new CustomerDaoServicesImpl();
	@Override
	public Customer acceptDetails(String name, String gstNumber, String occupation, String mobileNumber,
			String address) throws InvalidMobileNumberException, AlreadyRegisteredException, InvalidOccupationExcpetion  {
		Customer customer=new Customer(name,gstNumber,occupation,mobileNumber,address);
		boolean check=false;
		Set<Integer> set=SuperMarketDB.MarketDB.keySet();
		for(Integer s:set) {
			Customer customer1=SuperMarketDB.MarketDB.get(s);
			if((customer1.getGstNumber()).equals(customer.getGstNumber())) {
				check=true;
				break;
			}
		}
		if(check==true)
			throw new AlreadyRegisteredException();
		if(!(checkMobileNumber(mobileNumber)))
			throw new InvalidMobileNumberException();
		if(!(occupation.equalsIgnoreCase("Business")))
			throw new InvalidOccupationExcpetion();
		customer=daoServices.save(customer);
		return customer;
	}
	@Override
	public float getBill(int custId,ArrayList<String> product) throws CustomerNotFoundException, ProductNotFoundException  {
		int bill=0;
		OrderDB.orderList.clear();
		Customer customer=daoServices.findOne(custId);
		if(customer==null)
			throw new CustomerNotFoundException();
		else {
			ProductDB.addValues();
			for(String items:product) {
				if(checkProduct(items)) {
					bill=bill+ProductDB.productDb.get(items);
					OrderDB.orderList.add(items); }
				else
					throw new ProductNotFoundException(items+" not available");
			}
		    Order order=new Order(OrderDB.orderList, bill, OrderDB.getOrderId());
		     OrderDB.orderMap.put(order.getOrderId(), order);
			customer.setOrders(	OrderDB.orderMap);
			customer=daoServices.update(customer);
		}
		return bill;
	}
	@Override
	public HashMap<Integer,Order> getOrders(int custId) throws CustomerNotFoundException {
		Customer customer=daoServices.findOne(custId);
		if(customer==null)
			throw new CustomerNotFoundException();
		return customer.getOrders();
	}
	@Override
	public Customer getDetails(int custId) throws CustomerNotFoundException {
		Customer customer=daoServices.findOne(custId);
		if(customer==null)
			throw new CustomerNotFoundException();
		return customer;
	}
	public boolean checkMobileNumber(String mobileNumber) {
		Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher m = p.matcher(mobileNumber); 
		return (m.find() && m.group().equals(mobileNumber)); 
	}
	public boolean checkProduct(String pName) throws ProductNotFoundException {
		boolean value = true;
		ProductDB.addValues();
		for(String items:ProductDB.productDb.keySet()) {
			if(pName.equalsIgnoreCase(items)) {
				value=true;
				break;}
			else 
				value=false;
		}
		return value;
	}
}

package com.cg.supermarket.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.supermarket.exceptions.AlreadyRegisteredException;
import com.cg.supermarket.exceptions.CustomerNotFoundException;
import com.cg.supermarket.exceptions.InvalidMobileNumberException;
import com.cg.supermarket.exceptions.InvalidOccupationExcpetion;
import com.cg.supermarket.exceptions.ProductNotFoundException;
import com.cg.supermarket.services.MarketServices;
import com.cg.supermarket.services.ServicesImpl;
import com.cg.supermarket.util.SuperMarketDB;
public class ClientPresentation {
	public static void main(String args[]) throws InvalidMobileNumberException, AlreadyRegisteredException, InvalidOccupationExcpetion, CustomerNotFoundException {
		ArrayList<String> al=new ArrayList<>();
		char continueChoice='y';
		int choice;
		MarketServices services=new ServicesImpl();
		do {
			System.out.println("Enter your choice: ");
			System.out.println("Enter 1 to register"+"\n Enter 2 to  generate bill"+"\n Enter 3 to get order details"
					+"\n Enter 4 to get customer details");
			Scanner scan=new Scanner(System.in);
			choice=scan.nextInt();
			switch(choice) {
			case 1:
				try {
					System.out.println("Enter your name:");
					String name=scan.next();
					System.out.println("Enter your GST Number:");
					String gstNumber=scan.next();
					System.out.println("Enter your occupation:");
					String occupation=scan.next();
					System.out.println("Enter your Mobile Number:");
					String mobileNumber=scan.next();
					System.out.println("Enter your address:");
					String address=scan.next();
					System.out.println(services.acceptDetails(name, gstNumber, occupation, mobileNumber, address));
				}
				catch(AlreadyRegisteredException e) {
					System.out.println("You can register only once. Your GST No is already registered with us");
				}
				catch(InvalidOccupationExcpetion e) {
					System.out.println("Only Business with GST Number can register with us");
				}
				catch(InvalidMobileNumberException e) {
					System.out.println("Check your mobile number");
				}
				break;
			case 2:
				String itemName;
				char answer='y';
				try {
					System.out.println("Enter your Identification Number: ");
					int id=scan.nextInt();
					System.out.println("Enter the items you want to purchase:  ");
					do {
						System.out.println("Please enter product: ");
						itemName=scan.next();
						al.add(itemName.toUpperCase());
						System.out.println(al);
						System.out.println("Do you want to add a product  y/n?");
						answer = scan.next().charAt(0); 
					}
					while(answer=='y'||answer=='Y');
					System.out.println("\nYour Total Bill= "+services.getBill(id, al));
					System.out.println("************Thanks for shopping***************");
					al.clear();
				}

				catch(ProductNotFoundException e) {
					e.printStackTrace();
					System.out.println("Please enter valid product");
				}
				catch(CustomerNotFoundException e) {
					System.out.println("Customer not registered. Please register to continue");
				}
				break;
			case 3: 
				System.out.println("Enter your Identification Number: ");
				int custId=scan.nextInt();
				System.out.println(services.getOrders(custId));
				break;
			case 4:
				System.out.println("Enter your Identification Number: ");
				int id=scan.nextInt();
				System.out.println(services.getDetails(id));
				break;
			default:
				System.out.println("Wrong choice");
			}
			System.out.println("\n Do you want to continue (y or n): ");
			continueChoice=scan.next().charAt(0);
		}
		while(continueChoice=='y'||continueChoice=='Y');
	} 
}




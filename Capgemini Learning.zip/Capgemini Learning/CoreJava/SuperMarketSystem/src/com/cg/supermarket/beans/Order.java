package com.cg.supermarket.beans;

import java.util.ArrayList;

public class Order {
	private ArrayList<String> name;
	private float bill;
	private int orderId;
	public Order() {};
	public Order(ArrayList<String> name, float bill, int orderId) {
		super();
		this.name = name;
		this.bill = bill;
		this.orderId = orderId;
	}
	public ArrayList<String> getName() {
		return name;
	}
	public void setName(ArrayList<String> name) {
		this.name = name;
	}
	public float getBill() {
		return bill;
	}
	public void setBill(float bill) {
		this.bill = bill;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	@Override
	public String toString() {
		return "Order [name=" + name + ", bill=" + bill + ", orderId=" + orderId + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(bill);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + orderId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (Float.floatToIntBits(bill) != Float.floatToIntBits(other.bill))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (orderId != other.orderId)
			return false;
		return true;
	}


}






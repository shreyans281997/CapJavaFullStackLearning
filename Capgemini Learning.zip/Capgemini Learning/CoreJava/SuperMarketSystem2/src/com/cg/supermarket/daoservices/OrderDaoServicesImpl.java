package com.cg.supermarket.daoservices;

import com.cg.supermarket.beans.Order;
import com.cg.supermarket.util.OrderDB;

public class OrderDaoServicesImpl implements OrderDaoServices {

	@Override
	public Order save(Order order) {
		order.setOrderId(OrderDB.getOrderId());
		return order;
	}

}

package com.cg.supermarket.daoservices;
import com.cg.supermarket.beans.Order;
public interface OrderDaoServices {
	Order save(Order order);
}

package com.cg.supermarket.util;

import java.util.HashMap;
public class ProductDB {
	public static HashMap<String,Integer> productDb=new HashMap<>();
	public static void addValues() {
		productDb.put("POTATO", 20);
		productDb.put("TOMATO", 23);
		productDb.put("CAULIFLOWER",30);
		productDb.put("APPLE",100);
	}
	
}

package com.cg.supermarket.util;
import java.util.HashMap;
import com.cg.supermarket.beans.Customer;
public class SuperMarketDB {
	public static int custId=100;
	public static HashMap<Integer, Customer> MarketDB=new HashMap<>();
	public static int getCustomerId() {
		return custId++;
	}
  }

package com.cg.supermarket.daoservices;
import java.util.List;

import com.cg.supermarket.beans.Customer;
public interface CustomerDaoServices {
	Customer update(Customer customer);
	Customer findOne(int custId);
	List<Customer> findAll();
	Customer save(Customer customer);

}

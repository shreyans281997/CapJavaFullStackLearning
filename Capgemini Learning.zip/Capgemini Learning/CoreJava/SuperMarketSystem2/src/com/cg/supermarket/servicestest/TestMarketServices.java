package com.cg.supermarket.servicestest;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.HashMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.supermarket.beans.Customer;
import com.cg.supermarket.beans.Order;
import com.cg.supermarket.exceptions.AlreadyRegisteredException;
import com.cg.supermarket.exceptions.CustomerNotFoundException;
import com.cg.supermarket.exceptions.InvalidMobileNumberException;
import com.cg.supermarket.exceptions.InvalidOccupationExcpetion;
import com.cg.supermarket.exceptions.ProductNotFoundException;
import com.cg.supermarket.services.MarketServices;
import com.cg.supermarket.services.ServicesImpl;
import com.cg.supermarket.util.OrderDB;
import com.cg.supermarket.util.ProductDB;
import com.cg.supermarket.util.SuperMarketDB;
public class TestMarketServices {
	private static MarketServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new ServicesImpl();
	}
	@Before
	public void setUpTestData() {
		HashMap<Integer,Order> order1=new HashMap<>();
		HashMap<Integer,Order> order2=new HashMap<>();
		ArrayList<String> arrList=new ArrayList<>();
		arrList.add("potato");
		arrList.add("tomato");
		Order orders1=new Order(arrList, 43, 1000);
		ArrayList<String> arrList2=new ArrayList<>();
		arrList2.add("potato");
		arrList2.add("apple");
		Order orders2=new Order(arrList, 43, 1001);
		order1.put(1000,orders1);
		order2.put(1001,orders2);
		Customer customer1=new Customer(100, "Rey", "abc001", "business", "9876543210", "mbd", order1);
		Customer customer2=new Customer(101, "Shreyans", "def001", "business", "7417709872", "ldh", order2);
		SuperMarketDB.MarketDB.put(customer1.getCustId(), customer1);
		SuperMarketDB.MarketDB.put(customer2.getCustId(), customer2);
		SuperMarketDB.custId=102;
		OrderDB.orderId=1001;
	}
	@Test(expected=AlreadyRegisteredException.class)
	public void testAcceptDetailsForAlreadyRegistered() throws AlreadyRegisteredException, InvalidMobileNumberException, InvalidOccupationExcpetion {
		services.acceptDetails("rey", "abc001","business", "9087605467", "mbd");
	}
	@Test(expected=InvalidOccupationExcpetion.class)
	public void testAcceptDetailsForInvalidOccupation() throws AlreadyRegisteredException, InvalidMobileNumberException, InvalidOccupationExcpetion {
		services.acceptDetails("rey", "bc0001","service", "9087605467", "mbd");
	}
	@Test(expected=InvalidMobileNumberException.class)
	public void testAcceptDetailsForInvalidMobileNumber() throws AlreadyRegisteredException, InvalidMobileNumberException, InvalidOccupationExcpetion {
		services.acceptDetails("rey", "bc0001","business", "908760546700", "mbd");
	}
	@Test
	public void testAccpetDetailsForValidData() throws AlreadyRegisteredException, InvalidMobileNumberException, InvalidOccupationExcpetion {
		HashMap<Integer,Order> order1=new HashMap<>();
		Customer expectedData=new Customer(102, "Rey", "erty000", "business", "7417709872", "Pune", order1);
		Customer actualData=services.acceptDetails("Rey", "erty000", "business","7417709872", "Pune");
		Assert.assertEquals(expectedData, actualData);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testgetBillForCustomerNotFound() throws CustomerNotFoundException, ProductNotFoundException{
		ArrayList<String> product=new ArrayList<>();
		product.add("potato");
		product.add("Tomato");
		services.getBill(1009, product);
	}
	@Test
   public void testgetBillForValidData() throws CustomerNotFoundException {
		ArrayList<String> product=new ArrayList<>();
		product.add("potato");
		product.add("Tomato");
		float expectedData= 43;
		System.out.println(services.getOrders(100));
	 float actualData=services.getBill(100, product);
	 Assert.assertEquals(expectedData, actualData, 0);
	}
	@After
	public void tearDownTestData() {
		SuperMarketDB.MarketDB.clear();
		SuperMarketDB.custId=100;
		OrderDB.orderId=1000;
	}
	@AfterClass
	public static void tearDownData() {
		services=null;
	}

}

package com.cg.supermarket.util;
import java.util.ArrayList;
import java.util.HashMap;
import com.cg.supermarket.beans.Order;
public class OrderDB {
	public static HashMap<Integer,Order> orderMap=new HashMap<>();
	public static ArrayList<String> orderList=new ArrayList<>();

public  static int orderId=1000;
public static int getOrderId() {
	return orderId++; 
}
}
package com.cg.projecy.beans;
import java.io.Serializable;
public class Customer implements Serializable {
	private static int CUSTOMER_ID_COUNTER;
	
	private int custId;
	private String firstName, LastName;
	private transient Address address;
	public Customer() {}
	public Customer(int custId, String firstName, String lastName, Address address) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		LastName = lastName;
		this.address = address;
	}
	public static int getCUSTOMER_ID_COUNTER() {
		return CUSTOMER_ID_COUNTER;
	}
	public static void setCUSTOMER_ID_COUNTER(int cUSTOMER_ID_COUNTER) {
		CUSTOMER_ID_COUNTER = cUSTOMER_ID_COUNTER;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	};
	

}

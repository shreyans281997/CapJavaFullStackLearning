package com.cg.function.consumer;

public interface WorkService {
	void doSomeWork();

}

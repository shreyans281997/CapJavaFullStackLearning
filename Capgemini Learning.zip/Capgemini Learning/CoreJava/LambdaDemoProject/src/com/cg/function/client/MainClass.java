package com.cg.function.client;
import com.cg.function.consumer.WorkService;
import com.cg.project.lambdainterface.FunctionalInterface1;
import com.cg.project.lambdainterface.FunctionalInterface2;
public class MainClass {
	public static void main(String args[]) {
		//method 1
		/*WorkService service=()->{
			System.out.println("Work is in progress");
			System.out.println("Work is done");
		}; 
		service.doSomeWork(); */
		
		//method 2
		//callForWork(()->System.out.println("----Work is is progress---"));
		
		FunctionalInterface1 ref1=(firstName,lastName)->System.out.println("GoodAfter Noon"+firstName+" "+lastName);
		ref1.greetUser("Shreyansh", "Jain");
		
		FunctionalInterface2 ref2=(a,b)-> a+b;
		System.out.println(ref2.add(4, 5));
	}
/*	public static void  callForWork(WorkService service) {
		service.doSomeWork(); 
		} */
}

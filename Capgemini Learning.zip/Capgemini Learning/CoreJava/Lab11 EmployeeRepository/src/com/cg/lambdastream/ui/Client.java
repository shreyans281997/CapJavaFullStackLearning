package com.cg.lambdastream.ui;
import com.cg.lambdastream.services.EmployeeService;
public class Client {
	public static void main(String[] args) {
		EmployeeService service=new EmployeeService();
		System.out.println("Total Salary : "+service.totalSal());
		System.out.println("\nDepartment information :");
		service.departmentInfo();
		System.out.println("\nEmployees without department : ");
		service.empWithoutDep();
		System.out.println("\nDepartment without employees : ");
		service.depWithoutEmp();
		System.out.println("\nDepartment having highest no. of employees");
		service.highestEmpDep();
	}
}
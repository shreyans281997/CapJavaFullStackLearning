package com.cg.lambdastream.util;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import com.cg.lambdastream.beans.*;
public class EmployeeRepository {
	public static HashMap<Integer, Employee> employees = new HashMap<>();
	public EmployeeRepository() {
		EmployeeRepository.employees.put(101, new Employee(101, 901, "Shreyansh", "Jain", "sh@gmail.com", "9865420525","Developer", LocalDate.of(2017, 11, 6), 20000, new Department(900, 901, "FSBU")));
		EmployeeRepository.employees.put(102, new Employee(102, 901, "Anil", "thakur", "ak@gmail.com", "9754890123","Developer", LocalDate.of(2017, 10, 9), 20000, new Department(900, 901, "FSBU")));
		EmployeeRepository.employees.put(103, new Employee(103, 901, "Sanjay", "Mahajan", "sm@gmail.com", "7657890123","Developer", LocalDate.of(2017, 12, 9), 20000, new Department(900, 901, "Training")));
		EmployeeRepository.employees.put(201, new Employee(201, 801, "Ishita", "Sharma", "is@gmail.com", "8743063456","Senior", LocalDate.of(2017, 5, 8), 15000, new Department(800, 801, "FSBU")));
		EmployeeRepository.employees.put(501, new Employee(501, 0, "Sandeep", "Jain", "ssj@gmail.com", "45457543390","Tester", LocalDate.of(2017, 3, 1), 20000, new Department(0, 0, "")));
		EmployeeRepository.employees.put(503, new Employee(503, 0, "Sanjay", "Jain", "sj@gmail.com", "9873098678","Developer", LocalDate.of(2017, 2, 17), 20000, new Department(0, 0, "")));
		EmployeeRepository.employees.put(504, new Employee(504, 0, "Ms", "Dhoni", "msd@gmail.com", "9123456780","Senior", LocalDate.of(2017, 5, 8), 15000, new Department(0, 0, "")));
		EmployeeRepository.employees.put(1, new Employee(0, 901, "", "", "", "","", LocalDate.of(1,1,1), 0, new Department(900, 901, "Training")));
		EmployeeRepository.employees.put(2, new Employee(0, 901, "", "", "", "","", LocalDate.of(1, 1, 1), 0, new Department(900, 901, "FSBU")));
		EmployeeRepository.employees.put(3, new Employee(0, 801, "", "", "", "","", LocalDate.of(1, 1, 1), 0, new Department(800, 801, "Training")));
	}
	public static HashMap<Integer, Employee> getEmployees() {
		return employees;
	}
	public static void setEmployees(HashMap<Integer, Employee> employees) {
		EmployeeRepository.employees = employees;
	}
}
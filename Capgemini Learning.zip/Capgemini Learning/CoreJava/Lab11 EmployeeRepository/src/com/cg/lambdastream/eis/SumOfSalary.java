package com.cg.lambdastream.eis;

public interface SumOfSalary {
	public double sumSalary();

}

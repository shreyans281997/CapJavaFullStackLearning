package com.cg.banking.util;
import com.cg.banking.beans.Account;
import java.util.HashMap;
public class BankingDB {
public static HashMap <Long ,Account> accountDB=new HashMap<>();
public static int ACCOUNT_NUMBER=12300018;
public static int ACCOUNT_PIN=999;
public static String ACCOUNT_STATUS="ACTIVE";
public static int getPinNumber() {
	return ++ACCOUNT_PIN;
}
public static int getAccNumber() {
	return ACCOUNT_NUMBER++;
}
public static String getAccStatus() {
	return ACCOUNT_STATUS;
}
	

}

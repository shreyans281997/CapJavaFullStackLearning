package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.TransactionDB;
public class TransactionDAOImpl implements TransactionDAO {
private static Connection con=TransactionDB.getDBConnection();
	@Override
	public Transaction save(Transaction transaction,long accountNumber) {
		try {
			con.setAutoCommit(false);
			long accountNo=accountNumber;
			PreparedStatement pstmt1=con.prepareStatement("INSERT INTO transactions(transactionId,accountNumber,amount,transactiontype) values(transactions_id_seq.NEXTVAL,?,?,?)");
		    pstmt1.setLong(1, accountNo);
		    pstmt1.setFloat(2, transaction.getAmount());
		    pstmt1.setString(3, transaction.getTransactionType());
		    pstmt1.executeUpdate();
		    con.commit();
		    } catch (SQLException e) {
			try {
				con.rollback();
			}
			catch(SQLException e1){
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Transaction findOne(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

}

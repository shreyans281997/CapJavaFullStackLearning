package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDB;
public class AccountDAOImpl implements AccountDAO{
	private static Connection con=BankingDB.getDBConnection();
	@Override
	public Account save(Account account) {
		
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("INSERT into Account(AccountNumber,PinNumber,AccountType,AccountStatus,AccountBalance) values(ACCOUNT_NUMBER_SEQ.NEXTVAL,PIN_NUMBER_SEQ.NEXTVAL,?,?,?)");
			pstmt1.setString(1, account.getAccountType());
			pstmt1.setString(2, "active");
			pstmt1.setFloat(3, account.getAccountBalance());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=con.prepareStatement("SELECT max(accountNumber) FROM account");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int accountNo=rs.getInt(1);
			account.setAccountNo(accountNo);
			PreparedStatement pstmt3=con.prepareStatement("SELECT max(pinNumber) FROM account");
			ResultSet rs1=pstmt3.executeQuery();
			rs1.next();
			int pinNo=rs.getInt(1);
			account.setPinNumber(pinNo);
			
			con.commit();
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}
			catch(SQLException e1){
				e1.printStackTrace();
			}
		}
		return account;
	}


	@Override
	public boolean update(Account account) {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("UPDATE account set accountBalance="+account.getAccountBalance()+"where accountNumber="+account.getAccountNo());
			//PreparedStatement pstmt2=con.prepareStatement("UPDATE account set accountStatus="+account.getAccountStatus()+"where accountNumber="+account.getAccountNo());
			//pstmt1.setFloat(1, account.getAccountBalance());
			//pstmt1.setString(2, account.getAccountStatus());
			pstmt1.executeUpdate();
			//pstmt2.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}
			catch(SQLException e1){
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		try {
			PreparedStatement pstmt=con.prepareStatement("Select * from Account where accountNumber="+accountNo);
		    ResultSet accountRs=pstmt.executeQuery();
		    if(accountRs.next()) {
		   float accountBalance=accountRs.getFloat("accountBalance");
		   String accountStatus=accountRs.getString("accountStatus");
		   String accountType=accountRs.getString("accountType");
		   int pinNumber=accountRs.getInt("pinNumber");
		   Account account=new Account(accountNo, pinNumber, accountType, accountStatus, accountBalance);
		   return account;
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}

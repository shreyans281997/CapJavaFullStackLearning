package com.cg.payroll.test;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTestEasyMock {

	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDAO;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	@Before
	public void setUpTestMockData() {
	Associate associate1=new Associate(101,78000,"Shreyansh","Jain","FSBU", "Analyst", "GIYs234R","eryj@gmail.com" 
	,new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","HDFC05"));
	Associate associate2=new Associate(102,88000,"Satish","Mahajan","training", "Manager", "HGDs234R","fyggf@gmail.com" 
	,new Salary(25000,1800,1800),new BankDetails(22345,"HDFC","HDFC05"));	
	Associate associate3=new Associate(48000,"Joey","Singh","training", "Analyst", "gdrs234R","joey@gmail.com" 
		,new Salary(78000,2800,4800),new BankDetails(27345,"HDFC","HDFC05"));	
	ArrayList<Associate>associatesList=new ArrayList<>();
	associatesList.add(associate1);
	associatesList.add(associate2);
	
	EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
	
	EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
	EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
	EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(null);
	EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
	EasyMock.expect(mockAssociateDAO);
	EasyMock.replay(mockAssociateDAO);
	}
	
	@Test(expected=AssociateDetailsNotfoundException.class)
	public void testGetAssociatedDataForInvalidAssociateId() throws AssociateDetailsNotfoundException{
	payrollServices.getAssociateDetails(1234);
	EasyMock.verify(mockAssociateDAO.findOne(1234));
	
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()
	throws AssociateDetailsNotfoundException{
		Associate expectedAssociate=new Associate(101,78000,"Shreyansh","Jain","FSBU", "Analyst", "GIYs234R","eryj@gmail.com" 
				,new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","HDFC05"));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		
		System.out.println(expectedAssociate);
		System.out.println(actualAssociate);
		assertEquals(expectedAssociate,actualAssociate);
		//EasyMock.verify(mockAssociateDAO.findOne(101));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDAO);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDAO=null;
		payrollServices=null;
	}
}
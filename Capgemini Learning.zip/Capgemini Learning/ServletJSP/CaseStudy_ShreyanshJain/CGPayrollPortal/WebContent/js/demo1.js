function sayHello() {
	document.getElementById("msg").innerHTML="<font color=red size=10>Hello World</font>"
	console.log("Console output");
}
function sayHello() {
	document.write("My name is shreyansh")
	console.log("Console output")
}
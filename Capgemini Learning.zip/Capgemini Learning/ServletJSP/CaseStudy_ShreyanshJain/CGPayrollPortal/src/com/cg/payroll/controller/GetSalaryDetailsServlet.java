package com.cg.payroll.controller;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;


@WebServlet("/salaryDetails")
public class GetSalaryDetailsServlet extends HttpServlet {
	private PayrollServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void init() throws ServletException {
		services=new PayrollServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int totalSalary = services.calculateNetSalary(Integer.parseInt(request.getParameter("associateId")));
			request.setAttribute("totalSalary", totalSalary);
			Associate associate=services.getAssociateDetails(Integer.parseInt(request.getParameter("associateId")));
			generatePdf(request, response, associate);
		}
		catch(AssociateDetailsNotfoundException e) {
			request.setAttribute("exception", e.getMessage());
			request.getRequestDispatcher("salarySlipPage.jsp").forward(request, response);
	}
}               void generatePdf(HttpServletRequest request, HttpServletResponse response, Associate associate)throws ServletException, IOException {
	        try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PdfDocument pdfDoc = new PdfDocument(new PdfWriter(baos));Document document=new Document(pdfDoc);
			@SuppressWarnings("deprecation")
			Table table=new Table(2);
			Cell cell = new Cell(1,2).add("Salary Slip").setTextAlignment(TextAlignment.CENTER);
			table.addCell(cell);
			table.addCell(new Cell().add("Basic salary"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getBasicSalary())));
			table.addCell(new Cell().add("Compnay PF"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getCompanyPf())));
			table.addCell(new Cell().add("EPF"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getEpf())));
			table.addCell(new Cell().add("Conveyence Allowance"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getConveyenceAllowance())));
			table.addCell(new Cell().add("Personal Allowance"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getPersonalAllowance())));
			table.addCell(new Cell().add("HRA"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getHra())));
			table.addCell(new Cell().add("Other Allowance"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getOtherAllowance())));
			table.addCell(new Cell().add("YearlyInvestmentUnder80c"));
			table.addCell(new Cell().add(Integer.toString(associate.getYearlyInvestmentUnder80C())));
			table.addCell(new Cell().add("Gross salary"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getGrossSalary())));
			table.addCell(new Cell().add("Monthly Tax"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getMonthlyTax())));
			table.addCell(new Cell().add("Net salary"));
			table.addCell(new Cell().add(Integer.toString(associate.getSalary().getNetSalary())));
			document.add(new Paragraph("AssociateID:"+Integer.toString(associate.getAssociateId())));
			document.add(new Paragraph("Document Generated On - "+new Date().toString()));	
			document.add(table);
			document.close();
			// setting some response headers
			response.setHeader("Expires", "0");
			response.setHeader("Cache-Control",
					"must-revalidate, post-check=0, pre-check=0");
			response.setHeader("Pragma", "public");
			// setting the content type
			response.setContentType("application/pdf");
			// the contentlength
			response.setContentLength(baos.size());
			// write ByteArrayOutputStream to the ServletOutputStream
			OutputStream os = response.getOutputStream();
			baos.writeTo(os);
			os.flush();
			os.close();
			System.out.println("Pdf created successfully..");

		}
		catch(Exception e) {
			request.setAttribute("exception", e.getMessage());
			request.getRequestDispatcher("salarySlipPage.jsp").forward(request, response);
		}
	}
	@Override
	public void destroy() {
		services=null;
	}

}

package com.cg.payroll.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

/**
 * Servlet implementation class GetAllAssociateDetailsServlet
 */
@WebServlet("/allAssociateDetails")
public class GetAllAssociateDetailsServlet extends HttpServlet {
	private PayrollServices services;
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {
		services=new PayrollServicesImpl();
	}
	public void destroy() {
		services=null;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			List<Associate> associates=new ArrayList<Associate>();
			associates=services.getAllAssociatesDetails();
			request.setAttribute("associates", associates);
			request.getRequestDispatcher("allAssociateDetailsPage.jsp").forward(request, response);
	
	}

}

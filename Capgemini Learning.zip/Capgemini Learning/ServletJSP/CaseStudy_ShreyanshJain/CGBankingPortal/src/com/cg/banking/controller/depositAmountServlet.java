package com.cg.banking.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/depositAmount")
public class depositAmountServlet extends HttpServlet {
	private BankingServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void destroy() {
		services=null;
	}
@Override
	public void init() throws ServletException {
		services=new BankingServicesImpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Account account=services.getAccountDetails(Integer.parseInt(request.getParameter("accountNumber")));
		request.setAttribute("totalBalance", services.depositAmount(Integer.parseInt(request.getParameter("accountNumber")),Integer.parseInt(request.getParameter("amount"))));
		request.setAttribute("transactionId", services.recentTransaction());
		request.setAttribute("sucess", "TransactionId: ");
		request.getRequestDispatcher("depositAmountPage.jsp").forward(request, response);
	}

}

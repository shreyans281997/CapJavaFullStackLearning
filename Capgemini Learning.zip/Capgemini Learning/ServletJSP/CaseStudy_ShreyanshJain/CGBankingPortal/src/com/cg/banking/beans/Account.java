package com.cg.banking.beans;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;
	private String firstName;
	private String lastName;
	private int pinNumber;
	private String accountType,accountStatus;
	private float accountBalance;
	@OneToMany(mappedBy="account")
	@MapKey
	public Map<Integer,Transaction> transactions;
	public Account(){}
public Account(String firstName, String lastName, int pinNumber, String accountType, String accountStatus,
			float accountBalance) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalance = accountBalance;
	}

public Account(String firstName, String lastName, String accountType, float accountBalance) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.accountType = accountType;
	this.accountBalance = accountBalance;
}
public Account(long accountNo, String firstName, String lastName, int pinNumber, String accountType,
		String accountStatus, float accountBalance, Map<Integer, Transaction> transactions) {
	super();
	this.accountNo = accountNo;
	this.firstName = firstName;
	this.lastName = lastName;
	this.pinNumber = pinNumber;
	this.accountType = accountType;
	this.accountStatus = accountStatus;
	this.accountBalance = accountBalance;
	this.transactions = transactions;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public int getPinNumber() {
	return pinNumber;
}
public void setPinNumber(int pinNumber) {
	this.pinNumber = pinNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getAccountStatus() {
	return accountStatus;
}
public void setAccountStatus(String accountStatus) {
	this.accountStatus = accountStatus;
}
public float getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(float accountBalance) {
	this.accountBalance = accountBalance;
}
public Map<Integer, Transaction> getTransactions() {
	return transactions;
}
public void setTransactions(Map<Integer, Transaction> transactions) {
	this.transactions = transactions;
}
@Override
public String toString() {
	return "Account [accountNo=" + accountNo + ", firstName=" + firstName + ", lastName=" + lastName + ", pinNumber="
			+ pinNumber + ", accountType=" + accountType + ", accountStatus=" + accountStatus + ", accountBalance="
			+ accountBalance + ", transactions=" + transactions + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Float.floatToIntBits(accountBalance);
	result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
	result = prime * result + ((accountStatus == null) ? 0 : accountStatus.hashCode());
	result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + pinNumber;
	result = prime * result + ((transactions == null) ? 0 : transactions.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Account other = (Account) obj;
	if (Float.floatToIntBits(accountBalance) != Float.floatToIntBits(other.accountBalance))
		return false;
	if (accountNo != other.accountNo)
		return false;
	if (accountStatus == null) {
		if (other.accountStatus != null)
			return false;
	} else if (!accountStatus.equals(other.accountStatus))
		return false;
	if (accountType == null) {
		if (other.accountType != null)
			return false;
	} else if (!accountType.equals(other.accountType))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (pinNumber != other.pinNumber)
		return false;
	if (transactions == null) {
		if (other.transactions != null)
			return false;
	} else if (!transactions.equals(other.transactions))
		return false;
	return true;
}

	
	
}


package com.cg.banking.services;
import java.util.HashMap;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDao;
	private TransactionDAO transactionDao;
	AccountDAOImpl daoImpl=new AccountDAOImpl();
	TransactionDAOImpl tDaoImpl=new TransactionDAOImpl();
	Transaction transaction;
	Transaction transaction1;
	Account account;
	Account account1;
	public BankingServicesImpl() {
		accountDao=new AccountDAOImpl();
		transactionDao=new TransactionDAOImpl();
	}
	public BankingServicesImpl(AccountDAO accountDao) {
		super();
		this.accountDao=accountDao;
	}
	public BankingServicesImpl(TransactionDAO transactionDao) {
		super();
		this.transactionDao=transactionDao;
	}
	@Override
	public Account openAccount(String firstName,String lastName,String accountType,float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if (initBalance<500)
			throw new InvalidAmountException("Deposit amount greater than 500");
		if ((accountType.equalsIgnoreCase("Savings")) || (accountType.equalsIgnoreCase("current")))
		{

			account=new Account(firstName,lastName,(int)(Math.random()*10000),accountType,"Active",initBalance);
			account=daoImpl.save(account);
		}
		else
			throw new InvalidAccountTypeException("Invalid type");
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=daoImpl.findOne((int) accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		else{
			account.setAccountBalance(account.getAccountBalance()+amount);
			daoImpl.update(account);
			transaction=new Transaction(amount,"Deposit",account);
			transaction=tDaoImpl.save(transaction);
		}
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) 
			throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		account=daoImpl.findOne((int) accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getAccountStatus().equalsIgnoreCase("blocked"))
             throw new AccountBlockedException("Sorry your account is blocked");
		if(account.getPinNumber()==pinNumber){
			if(amount>account.getAccountBalance())
				throw new InsufficientAmountException();
			else{
				account.setAccountBalance(account.getAccountBalance()-amount);
				transaction=new Transaction(amount,"Withdraw",account);
				tDaoImpl.save(transaction);
				daoImpl.update(account);
			}
		}
		else {
			throw new InvalidPinNumberException("Invalid Pin..Please Try Again!!");
		}
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		if(account.getAccountStatus().equalsIgnoreCase("blocked"))
            throw new AccountBlockedException("Sorry your account is blocked");
		int c=3;
		do {
			account=daoImpl.findOne(accountNoFrom);
			account1=daoImpl.findOne(accountNoTo);
			if(account==null || account1==null)
			{
				throw new AccountNotFoundException("Please enter valid account number");
			}
			else {
				if(account.getPinNumber()==pinNumber){
					if(transferAmount>account.getAccountBalance())
						throw new InsufficientAmountException("Insufficient balance in your account");
					else
						account.setAccountBalance(account.getAccountBalance()-transferAmount);
					account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
					transaction=new Transaction(transferAmount,"Withdraw",account);
					transaction1=new Transaction(transferAmount,"Deposit",account1);
					tDaoImpl.save(transaction);
					tDaoImpl.save(transaction1);
					daoImpl.update(account);
					daoImpl.update(account1);
				}
				else
				{
					c--;
					throw new InvalidPinNumberException("Invalid Pin..Please try again..!!");   }
			} 
		}
		while(account.getPinNumber()!=pinNumber);
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		account= daoImpl.findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("No Account found");
		return account;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException {
		return tDaoImpl.findAll(accountNo);
	}
	public int recentTransaction() {
		return tDaoImpl.findRecentTransaction();
	}
	@Override
	public String accountStatus(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= daoImpl.findOne(accountNo);
		return account.getAccountStatus();
	}
	@Override
	public void checkPin(int counter, long accountNo) throws AccountBlockedException {
		if(counter==0) {
			account.setAccountStatus("Blocked");
			daoImpl.update(account);
			throw new AccountBlockedException("Account blocked");
		}
	}
}

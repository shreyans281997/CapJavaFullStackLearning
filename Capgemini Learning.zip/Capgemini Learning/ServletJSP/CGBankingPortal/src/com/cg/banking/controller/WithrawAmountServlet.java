package com.cg.banking.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/withdrawAmount")
public class WithrawAmountServlet extends HttpServlet{
	private BankingServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void init() throws ServletException
	{
		services=new BankingServicesImpl();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int c=3;
		do {
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		try {
			float balance=services.withdrawAmount(accountNo, amount, pinNumber);
			c=-1;
			request.setAttribute("balance", balance);
			request.getRequestDispatcher("withdrawAmountPage.jsp").forward(request, response);	 
			}catch(AccountNotFoundException e){
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmountPage.jsp").forward(request, response);	
			}
		catch(InvalidPinNumberException e) {
			--c;
			try {
				services.checkPin(c, accountNo);
			}
			catch(AccountBlockedException e1) {
				request.setAttribute("error", e1.getMessage());
				request.getRequestDispatcher("withdrawAmountPage.jsp").forward(request, response);
			}
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmountPage.jsp").forward(request, response);
		}
		}
		while(c>0);
	}
	
	@Override
	public void destroy() 
	{
		services=null;
	}
}


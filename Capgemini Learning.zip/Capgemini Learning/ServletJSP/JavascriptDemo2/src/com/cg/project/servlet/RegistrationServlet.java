package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
        String emailId=request.getParameter("emailId");
        String department=request.getParameter("department");
        String designation=request.getParameter("designation");
        String panCard=request.getParameter("panCard");
        String accountNumber=request.getParameter("accountNumber");
        PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<div>");
		out.println(firstName+"-"+lastName+"-"+emailId+"-"+department+"-"+designation+"-"+panCard+"-"+accountNumber);
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
        
	}

}

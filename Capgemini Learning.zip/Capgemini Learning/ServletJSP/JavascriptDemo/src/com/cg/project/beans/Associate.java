package com.cg.project.beans;

import java.util.List;

public class Associate {
private int associateId;
private String firstName,lastName,emailId,password,department,designation,panCard;
private List<String> contact;
public Associate(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}

public Associate(int associateId, String firstName, String lastName, String emailId, String password, String department,
		String designation, String panCard, List<String> contact) {
	super();
	this.associateId = associateId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.password = password;
	this.department = department;
	this.designation = designation;
	this.panCard = panCard;
	this.contact = contact;
}


public Associate(String firstName, String lastName, String emailId, String department, String designation,
		String panCard, List<String> contact) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.department = department;
	this.designation = designation;
	this.panCard = panCard;
	this.contact = contact;
}

public int getAssociateId() {
	return associateId;
}

public void setAssociateId(int associateId) {
	this.associateId = associateId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getDepartment() {
	return department;
}

public void setDepartment(String department) {
	this.department = department;
}

public String getDesignation() {
	return designation;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

public String getPanCard() {
	return panCard;
}

public void setPanCard(String panCard) {
	this.panCard = panCard;
}

public List<String> getContact() {
	return contact;
}

public void setContact(List<String> contact) {
	this.contact = contact;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + associateId;
	result = prime * result + ((contact == null) ? 0 : contact.hashCode());
	result = prime * result + ((department == null) ? 0 : department.hashCode());
	result = prime * result + ((designation == null) ? 0 : designation.hashCode());
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((panCard == null) ? 0 : panCard.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Associate other = (Associate) obj;
	if (associateId != other.associateId)
		return false;
	if (contact == null) {
		if (other.contact != null)
			return false;
	} else if (!contact.equals(other.contact))
		return false;
	if (department == null) {
		if (other.department != null)
			return false;
	} else if (!department.equals(other.department))
		return false;
	if (designation == null) {
		if (other.designation != null)
			return false;
	} else if (!designation.equals(other.designation))
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (panCard == null) {
		if (other.panCard != null)
			return false;
	} else if (!panCard.equals(other.panCard))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	return true;
}

@Override
public String toString() {
	return "Associate [associateId=" + associateId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", emailId=" + emailId + ", password=" + password + ", department=" + department + ", designation="
			+ designation + ", panCard=" + panCard + ", contact=" + contact + "]";
}


}





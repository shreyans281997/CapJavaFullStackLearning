package com.cg.project.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {
	@Given("^User is on the main page of 'www\\.cgbankingsystem\\.com'$")
	public void user_is_on_the_main_page_of_www_cgbankingsystem_com() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user searches for account$")
	public void user_searches_for_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^search page should be updated with list of accounts$")
	public void search_page_should_be_updated_with_list_of_accounts() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}

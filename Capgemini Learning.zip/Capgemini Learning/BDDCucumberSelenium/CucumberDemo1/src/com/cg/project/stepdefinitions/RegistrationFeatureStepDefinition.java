package com.cg.project.stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.RegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationFeatureStepDefinition {
	private WebDriver driver;
	private RegistrationPageBean registrationPage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\3000152_Shreyansh_Jain\\chromeDriver.exe");

	}
	@Given("^User is accessing RegistrationPage on Browser$")
	public void user_is_accessing_RegistrationPage_on_Browser() throws Throwable {
       driver=new ChromeDriver();
       driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Downloads\\WebPages\\RegistrationForm.html");
		registrationPage=PageFactory.initElements(driver, RegistrationPageBean.class);
       
	}

	@When("^user is trying to submit data without entering 'User Id'$")
	public void user_is_trying_to_submit_data_without_entering_User_Id() throws Throwable {
	    throw new PendingException();
	}

	@Then("^'User Id should not be empty/length bebetween (\\d+) to (\\d+)' alert message should display$")
	public void user_Id_should_not_be_empty_length_bebetween_to_alert_message_should_display(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering 'Password'$")
	public void user_is_trying_to_submit_request_without_entering_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Password should not be empty/length be between (\\d+) to (\\d+)'$")
	public void password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit request without entering name$")
	public void user_is_trying_to_submit_request_without_entering_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Name should not be empty and must have alphabet characters only'$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit request without entering address$")
	public void user_is_trying_to_submit_request_without_entering_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'User address must have alphanumeric characters only'$")
	public void user_address_must_have_alphanumeric_characters_only() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit request without selecting country$")
	public void user_is_trying_to_submit_request_without_selecting_country() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Select your country from the list'$")
	public void select_your_country_from_the_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit request without entering email$")
	public void user_is_trying_to_submit_request_without_entering_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'You have entered an invalid email address!'$")
	public void you_have_entered_an_invalid_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	@After
	  public void tearDownStepEnv() {
		  driver.close();
	  }
}

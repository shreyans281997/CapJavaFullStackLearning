package com.cg.github.pagebeans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPageBean {
     @FindBy(how=How.NAME, name="userid")
	private WebElement userId;
     @FindBy(how=How.NAME,name="password")
     private WebElement password;
     @FindBy(how=How.NAME,name="submit")
     private WebElement submitBtn;
     @FindBy(how=How.NAME,name="username")
     private WebElement userName;
     @FindBy(how=How.NAME,name="address")
     private WebElement address;
     @FindBy(how=How.NAME,name="country")
     private WebElement country;
     @FindBy(how=How.NAME,name="zip")
     private WebElement zip;
     @FindBy(how=How.NAME,name="email")
     private WebElement email;
     @FindBy(how=How.NAME,name="gender")
     private WebElement gender;
	public String getUserId() {
		return userId.getAttribute("value");
	}
	public void setUserId(WebElement userId) {
		this.userId = userId;
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(WebElement password) {
		this.password = password;
	}
     
     
}
